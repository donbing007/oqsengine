Searching
=========

.. toctree::
   :glob:	
   
   searching/matching_modes
   searching/boolean_query_syntax
   searching/escaping_in_queries
   searching/extended_query_syntax
   searching/search_results_ranking
   searching/expressions,_functions,_and_operators
   searching/sorting_modes
   searching/grouping_clustering_search_results
   searching/distributed_searching
   searching/searchd_query_log_formats
   searching/mysql_protocol_support_and_sphinxql
   searching/multi-queries
   searching/faceted_search
   searching/geosearching
   searching/collations
   searching/query_cache
   mysql_storage_engine_sphinxse
   federated_storage_engine
   searching/percolate_query
