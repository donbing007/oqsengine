Gettting Started
================

.. toctree::
   :glob:	
   
   getting-started/docker
   getting-started/official-packages
   getting-started/migrate_from_manticore2
   getting-started/configuration
   getting-started/connectivity
   getting-started/indexes
   getting-started/searching
   