.. _show_databases_syntax:

SHOW DATABASES syntax
---------------------

.. code-block:: mysql


    SHOW DATABASES

This is a dummy statement to support MySQL Workbench and other clients
that require it. Currently, it does absolutely nothing.
