.. _begin_syntax:

BEGIN syntax
------------

.. code-block:: mysql


    START TRANSACTION | BEGIN

BEGIN syntax is discussed in detail in :ref:`begin,_commit,_and_rollback_syntax`.
