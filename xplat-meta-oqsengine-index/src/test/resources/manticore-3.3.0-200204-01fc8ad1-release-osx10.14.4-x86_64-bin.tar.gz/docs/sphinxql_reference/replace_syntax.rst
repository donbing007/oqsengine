.. _replace_syntax:

REPLACE syntax
--------------

.. code-block:: none


    {INSERT | REPLACE} INTO index [(column, ...)]
        VALUES (value, ...)
        [, (...)]

REPLACE syntax is identical to INSERT syntax and is described in :ref:`insert_and_replace_syntax`.
