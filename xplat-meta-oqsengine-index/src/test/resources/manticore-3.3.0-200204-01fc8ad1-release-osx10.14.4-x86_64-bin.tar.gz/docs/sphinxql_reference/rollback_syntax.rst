.. _rollback_syntax:

ROLLBACK syntax
---------------

.. code-block:: mysql


    ROLLBACK

ROLLBACK syntax is discussed in detail in :ref:`begin,_commit,_and_rollback_syntax`.
